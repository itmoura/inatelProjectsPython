class Produto:
    def __init__(self, nome, preco):
        self.nome = nome

        if preco < 0:
            raise ValueError("O Preço não pode ser menor que ZERO!!")
        else:
            self.preco = preco

    def getDescricao(self):
        print(f"Nome: {self.nome}")
        print("Preço: ", self.preco)