from Produto import Produto

class Livro(Produto):
    def __init__(self, nome, preco, autor):
        super().__init__(nome, preco)
        self.autor = autor

    def getDescricao(self):
        super().getDescricao()
        print("Autor: ", self.autor)