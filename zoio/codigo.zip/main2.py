from Mouse import Mouse
from Livro import Livro

produto1 = Mouse("Mouse", 250.00, "Mouse ótico, Saída USB. 1.600 dpi")

produto1.getDescricao()

print("-----------------")
produto2 = Livro("Senhor dos Aneis", 85.00, "J.R.R Tolkien")

produto2.getDescricao()

