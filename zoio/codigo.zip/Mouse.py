from Produto import Produto

class Mouse(Produto):
    def __init__(self, nome, preco, tipo):
        super().__init__(nome, preco)
        self.tipo = tipo

    def getDescricao(self):
        super().getDescricao()
        print("Tipo: ", self.tipo)